<?php
// index.php
// Redirects to the login page default
header("Location: login.php");
exit();
?>